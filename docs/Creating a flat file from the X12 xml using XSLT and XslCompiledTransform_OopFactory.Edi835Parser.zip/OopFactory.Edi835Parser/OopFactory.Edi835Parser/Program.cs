﻿using System.Text;
using System.IO;
using System.Reflection;
using System;
using System.Xml;
using System.Xml.Xsl;
using OopFactory.X12.Parsing;
using OopFactory.X12.Parsing.Model;

namespace OopFactory.Edi835Parser
{
    class Program
    {
        static void Main(string[] args)
        {
            Stream transformStream = null;
            
            
            Stream inputStream = new FileStream(args[0], FileMode.Open, FileAccess.Read);
            FileInfo outputFileInfo = new FileInfo(args[1]);

            if (outputFileInfo.Extension == ".xml")
                transformStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("OopFactory.Edi835Parser.Transformations.X12-835-XML-to-Excel-XML.xslt");
            else
                transformStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("OopFactory.Edi835Parser.Transformations.X12-835-XML-to-CSV.xslt");
            

            X12Parser parser = new X12Parser();
            Interchange interchange = parser.Parse(inputStream);
            interchange.SerializeToX12(true);
            string xml = interchange.Serialize();

            var transform = new XslCompiledTransform();
            transform.Load(XmlReader.Create(transformStream));
            XsltArgumentList arguments = new XsltArgumentList();
            arguments.AddParam("filename", "", new FileInfo(args[0]).Name);

            MemoryStream mstream = new MemoryStream();
            transform.Transform(XmlReader.Create(new StringReader(xml)), arguments, mstream);
            mstream.Flush();
            mstream.Position = 0;
            string content = new StreamReader(mstream).ReadToEnd();
            {
                string filename = String.Format("{0}\\{1}{2}", outputFileInfo.DirectoryName, outputFileInfo.Name.Replace(outputFileInfo.Extension, ""), outputFileInfo.Extension);
                using (Stream outputStream = new FileStream(filename, FileMode.Create, FileAccess.Write))
                {
                    using (StreamWriter writer = new StreamWriter(outputStream))
                    {
                        writer.Write(content);
                        writer.Close();
                    }
                    outputStream.Close();
                }

            }
            /*
            string[] csvs = content.Split(new char[] {'|'}, System.StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < csvs.Length; i++)
            {
                string filename = String.Format("{0}\\{1}_{3:000}{2}", outputFileInfo.DirectoryName, outputFileInfo.Name.Replace(outputFileInfo.Extension,""), outputFileInfo.Extension, i + 1);
                using (Stream outputStream = new FileStream(filename, FileMode.Create, FileAccess.Write))
                {
                    using (StreamWriter writer = new StreamWriter(outputStream))
                    {
                        writer.Write(csvs[i]);
                        writer.Close();
                    }
                    outputStream.Close();
                }
            }
             */
        }
    }
}
