﻿using System;
using System.IO;
using System.Reflection;
using OopFactory.X12.Parsing;
using OopFactory.X12.Parsing.Specification;

namespace MyCustomParser
{
    public class MySpecificationFinder : SpecificationFinder
    {
        public override OopFactory.X12.Parsing.Specification.TransactionSpecification FindTransactionSpec(string functionalCode, string versionCode, string transactionSetCode)
        {
            if (transactionSetCode == "997")
            {
                Stream specStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("MyCustomParser.My997Spec.xml");
                return TransactionSpecification.Deserialize(new StreamReader(specStream).ReadToEnd());
            }
            else
                return base.FindTransactionSpec(functionalCode, versionCode, transactionSetCode);
        }
    }
}
